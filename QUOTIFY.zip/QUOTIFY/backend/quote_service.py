import requests

API_URL = "https://dummyjson.com/quotes/random"
TIMEOUT = 8

# Keyword-based categorisation of fetched quotes (the external API has no categories).
CATEGORIES = {
    "Motivation": ["dream", "goal", "believe", "persist", "effort", "action", "never give", "courage", "begin", "start"],
    "Success": ["success", "succeed", "achieve", "win", "fail", "victory", "accomplish", "work hard"],
    "Love": ["love", "heart", "passion", "kiss", "romance", "beloved"],
    "Happiness": ["happy", "happiness", "joy", "smile", "laugh", "cheer", "peace"],
    "Life": ["life", "live", "living", "death", "world", "time", "day"],
    "Wisdom": ["wisdom", "wise", "knowledge", "truth", "learn", "mind", "think", "understand"],
    "Leadership": ["lead", "leader", "team", "vision", "follow", "inspire", "command"],
}


class QuoteServiceError(Exception):
    def __init__(self, message, status=502):
        super().__init__(message)
        self.status = status


def categorize(text):
    t = text.lower()
    scores = {c: sum(k in t for k in kws) for c, kws in CATEGORIES.items()}
    best = max(scores, key=scores.get)
    return best if scores[best] > 0 else "General"


def fetch_random_quote():
    try:
        resp = requests.get(API_URL, timeout=TIMEOUT)
    except requests.exceptions.Timeout:
        raise QuoteServiceError("The quote service is responding slowly. Please try again.", 504)
    except requests.exceptions.RequestException:
        raise QuoteServiceError("Could not reach the quote service. Check your internet connection.", 502)
    if resp.status_code != 200:
        raise QuoteServiceError("The quote service is unavailable right now.", 502)
    try:
        data = resp.json()
    except ValueError:
        raise QuoteServiceError("The quote service returned an invalid response.", 502)
    if not isinstance(data, dict):
        raise QuoteServiceError("The quote service returned an invalid response.", 502)
    quote, author = data.get("quote"), data.get("author")
    if not isinstance(quote, str) or not quote.strip() or not isinstance(author, str) or not author.strip():
        raise QuoteServiceError("The quote service returned an empty or invalid quote.", 502)
    api_id = data.get("id") if isinstance(data.get("id"), int) else None
    return {"api_id": api_id, "quote": quote.strip(), "author": author.strip(), "category": categorize(quote)}
