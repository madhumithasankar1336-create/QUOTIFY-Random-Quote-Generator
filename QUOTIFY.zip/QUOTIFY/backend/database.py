import os
import sqlite3
from contextlib import contextmanager

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "quotify.db")


@contextmanager
def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except sqlite3.Error:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    with db() as c:
        c.execute(
            """CREATE TABLE IF NOT EXISTS quotes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                api_id INTEGER,
                quote TEXT NOT NULL,
                author TEXT NOT NULL,
                category TEXT,
                is_favorite INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP)"""
        )


def _row(r):
    return dict(r) if r else None


def insert_quote(api_id, quote, author, category):
    with db() as c:
        cur = c.execute(
            "INSERT INTO quotes (api_id, quote, author, category) VALUES (?, ?, ?, ?)",
            (api_id, quote, author, category),
        )
        return _row(c.execute("SELECT * FROM quotes WHERE id = ?", (cur.lastrowid,)).fetchone())


def list_quotes(search="", sort="newest", category="", favorites_only=False, page=1, per_page=10):
    where, params = [], []
    if favorites_only:
        where.append("is_favorite = 1")
    if search:
        where.append("(quote LIKE ? OR author LIKE ?)")
        params += [f"%{search}%", f"%{search}%"]
    if category:
        where.append("category = ?")
        params.append(category)
    clause = ("WHERE " + " AND ".join(where)) if where else ""
    order = "ASC" if sort == "oldest" else "DESC"
    with db() as c:
        total = c.execute(f"SELECT COUNT(*) FROM quotes {clause}", params).fetchone()[0]
        rows = c.execute(
            f"SELECT * FROM quotes {clause} ORDER BY created_at {order}, id {order} LIMIT ? OFFSET ?",
            params + [per_page, (page - 1) * per_page],
        ).fetchall()
    return [dict(r) for r in rows], total


def toggle_favorite(qid):
    with db() as c:
        cur = c.execute("UPDATE quotes SET is_favorite = 1 - is_favorite WHERE id = ?", (qid,))
        if cur.rowcount == 0:
            return None
        return _row(c.execute("SELECT * FROM quotes WHERE id = ?", (qid,)).fetchone())


def delete_quote(qid):
    with db() as c:
        return c.execute("DELETE FROM quotes WHERE id = ?", (qid,)).rowcount > 0


def clear_all():
    with db() as c:
        return c.execute("DELETE FROM quotes").rowcount


def quote_at(offset):
    with db() as c:
        return _row(c.execute("SELECT * FROM quotes ORDER BY id LIMIT 1 OFFSET ?", (offset,)).fetchone())


def analytics():
    with db() as c:
        total = c.execute("SELECT COUNT(*) FROM quotes").fetchone()[0]
        favs = c.execute("SELECT COUNT(*) FROM quotes WHERE is_favorite = 1").fetchone()[0]
        authors = c.execute("SELECT COUNT(DISTINCT author) FROM quotes").fetchone()[0]
        top = c.execute(
            "SELECT author, COUNT(*) AS n FROM quotes GROUP BY author ORDER BY n DESC, author LIMIT 1"
        ).fetchone()
        recent = c.execute(
            "SELECT id, quote, author, created_at FROM quotes ORDER BY created_at DESC, id DESC LIMIT 5"
        ).fetchall()
    return {
        "total_quotes": total,
        "total_favorites": favs,
        "unique_authors": authors,
        "top_author": {"name": top["author"], "count": top["n"]} if top else None,
        "recent_activity": [dict(r) for r in recent],
    }
