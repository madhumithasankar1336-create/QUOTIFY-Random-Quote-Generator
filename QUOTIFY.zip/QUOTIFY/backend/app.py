import datetime
import hashlib
import logging
import sqlite3

from flask import Flask, jsonify, request
from flask_cors import CORS

import database as db
from quote_service import QuoteServiceError, fetch_random_quote

app = Flask(__name__)
CORS(app)
logging.basicConfig(level=logging.INFO)
log = logging.getLogger("quotify")
db.init_db()


def ok(**kw):
    return jsonify(success=True, **kw)


def fail(msg, code):
    return jsonify(success=False, error=msg), code


def int_arg(name, default, lo, hi):
    try:
        return max(lo, min(hi, int(request.args.get(name, default))))
    except (TypeError, ValueError):
        return default


def list_response(favorites_only):
    sort = request.args.get("sort", "newest")
    if sort not in ("newest", "oldest"):
        return fail("Invalid sort value.", 400)
    page, per = int_arg("page", 1, 1, 100000), int_arg("per_page", 10, 1, 50)
    items, total = db.list_quotes(
        request.args.get("search", "").strip()[:100], sort,
        request.args.get("category", "").strip()[:30], favorites_only, page, per,
    )
    return ok(items=items, total=total, page=page, has_more=page * per < total)


@app.get("/api/health")
def health():
    return ok(status="running")


@app.get("/api/quote/random")
def random_quote():
    try:
        data = fetch_random_quote()
    except QuoteServiceError as e:
        return fail(str(e), e.status)
    try:
        saved = db.insert_quote(data["api_id"], data["quote"], data["author"], data["category"])
    except sqlite3.Error:
        log.exception("insert failed")
        return fail("The quote could not be saved. Please try again.", 500)
    return ok(quote=saved)


@app.get("/api/quotes/history")
def history():
    try:
        return list_response(False)
    except sqlite3.Error:
        log.exception("history failed")
        return fail("Could not load history.", 500)


@app.get("/api/quotes/favorites")
def favorites():
    try:
        return list_response(True)
    except sqlite3.Error:
        log.exception("favorites failed")
        return fail("Could not load favorites.", 500)


@app.get("/api/quotes/featured")
def featured():
    """Daily inspiration: one saved quote, stable for the whole day."""
    try:
        total = db.list_quotes(per_page=1)[1]
        if total == 0:
            return fail("No quotes saved yet.", 404)
        seed = int(hashlib.md5(datetime.date.today().isoformat().encode()).hexdigest(), 16)
        return ok(quote=db.quote_at(seed % total))
    except sqlite3.Error:
        log.exception("featured failed")
        return fail("Could not load the featured quote.", 500)


@app.put("/api/quotes/<int:qid>/favorite")
def favorite(qid):
    try:
        q = db.toggle_favorite(qid)
    except sqlite3.Error:
        log.exception("favorite failed")
        return fail("Could not update favorite.", 500)
    return ok(quote=q) if q else fail("Quote not found.", 404)


@app.delete("/api/quotes/history")
def clear_history():
    try:
        return ok(deleted=db.clear_all())
    except sqlite3.Error:
        log.exception("clear failed")
        return fail("Could not clear history.", 500)


@app.delete("/api/quotes/<int:qid>")
def delete(qid):
    try:
        removed = db.delete_quote(qid)
    except sqlite3.Error:
        log.exception("delete failed")
        return fail("Could not delete the quote.", 500)
    return ok() if removed else fail("Quote not found.", 404)


@app.get("/api/analytics")
def analytics():
    try:
        return ok(**db.analytics())
    except sqlite3.Error:
        log.exception("analytics failed")
        return fail("Could not load statistics.", 500)


@app.errorhandler(404)
def not_found(_):
    return fail("Endpoint not found.", 404)


@app.errorhandler(405)
def bad_method(_):
    return fail("Method not allowed.", 405)


@app.errorhandler(Exception)
def unexpected(e):
    log.exception("unexpected error")
    return fail("Something went wrong on the server.", 500)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
