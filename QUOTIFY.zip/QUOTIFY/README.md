# QUOTIFY – Smart Quote Generator
Task 4: Quote Generator with History. A Flask + SQLite backend fetches random quotes from `https://dummyjson.com/quotes/random`, saves every successful fetch, and a vanilla JS frontend displays, searches and manages them.

## Features
Quote generator with Retry on failure · persistent history (search, sort, load more, delete, clear all) · favorites · keyword-based categories (assigned by QUOTIFY, not the API) · daily inspiration · copy / Web Share · inspiration mode · statistics · dark mode (saved in localStorage) · shortcuts (Space, Ctrl+C, Esc).

## Stack
HTML5, CSS3, vanilla JS · Python, Flask, Flask-CORS, Requests · SQLite (`sqlite3`).

## Structure
```
QUOTIFY/
├── frontend/ (index.html, history.html, favorites.html, css/style.css, js/{app,history,favorites,theme}.js, assets/)
├── backend/  (app.py, database.py, quote_service.py, requirements.txt, quotify.db – created on first run)
├── .gitignore
└── README.md
```

## Run (Windows PowerShell)
```
cd backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```
Backend: http://127.0.0.1:5000. Open the `QUOTIFY` folder in VS Code, right-click `frontend/index.html` → **Open with Live Server**:
**http://127.0.0.1:5500/frontend/index.html** (if you opened the `frontend` folder itself, use http://127.0.0.1:5500/index.html).
If PowerShell blocks activation: `Set-ExecutionPolicy -Scope Process Bypass`.

## API
All responses: `{"success": true, ...}` or `{"success": false, "error": "..."}`.
| Method | Endpoint | Purpose |
|---|---|---|
| GET | /api/health | Backend status |
| GET | /api/quote/random | Fetch, validate, save, return a quote (502/504 if the external API fails) |
| GET | /api/quotes/history?search=&sort=newest\|oldest&category=&page=&per_page= | Saved quotes |
| GET | /api/quotes/favorites | Favorites (same query options) |
| GET | /api/quotes/featured | Daily inspiration (stable per day) |
| PUT | /api/quotes/&lt;id&gt;/favorite | Toggle favorite |
| DELETE | /api/quotes/&lt;id&gt; | Delete one quote |
| DELETE | /api/quotes/history | Clear all history |
| GET | /api/analytics | Totals, unique authors, top author, recent activity |

## Database
`backend/quotify.db`, table `quotes(id, api_id, quote, author, category, is_favorite, created_at)`; created automatically; parameterized queries only.

## Future enhancements
Export history, user accounts, daily reminders, shareable image cards.

## Developer
Task 4 portfolio project. Add your name and links here.
