document.addEventListener("DOMContentLoaded", () => initList({ favoritesOnly: true }));
