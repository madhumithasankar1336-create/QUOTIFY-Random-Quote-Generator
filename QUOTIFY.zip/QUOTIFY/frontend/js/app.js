const API = "http://127.0.0.1:5000/api";
const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

function toast(msg, type = "ok") {
  let box = $("#toasts");
  if (!box) { box = document.createElement("div"); box.id = "toasts"; document.body.appendChild(box); }
  const t = document.createElement("div");
  t.className = "toast " + (type === "error" ? "error" : "");
  t.textContent = msg;
  box.appendChild(t);
  setTimeout(() => t.remove(), 3200);
}

async function api(path, opts = {}) {
  let res;
  try { res = await fetch(API + path, opts); }
  catch (e) { throw new Error("Cannot reach the QUOTIFY server. Make sure the backend is running on port 5000."); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok || data.success === false) throw new Error(data.error || "Request failed.");
  return data;
}

async function copyText(text) {
  try { await navigator.clipboard.writeText(text); }
  catch (e) {
    const ta = document.createElement("textarea");
    ta.value = text; document.body.appendChild(ta); ta.select();
    const done = document.execCommand("copy"); ta.remove();
    if (!done) { toast("Copy failed. Select the text and copy it manually.", "error"); return; }
  }
  toast("Copied successfully");
}
const fmt = (q) => `"${q.quote}" — ${q.author}`;
async function shareQuote(q) {
  if (navigator.share) {
    try { await navigator.share({ title: "QUOTIFY", text: fmt(q) }); } catch (e) { /* cancelled */ }
  } else { await copyText(fmt(q)); toast("Sharing isn't supported here, so the quote was copied."); }
}
const fmtDate = (s) => new Date(s.replace(" ", "T") + "Z").toLocaleString([], { dateStyle: "medium", timeStyle: "short" });

function confirmDialog(message) {
  return new Promise((resolve) => {
    const m = document.createElement("div");
    m.className = "modal open";
    m.innerHTML = `<div class="card dialog"><p>${esc(message)}</p><div class="row"><button class="btn" data-v="0">Cancel</button><button class="btn primary" data-v="1">Confirm</button></div></div>`;
    const done = (v) => { m.remove(); document.removeEventListener("keydown", onKey); resolve(v); };
    const onKey = (e) => { if (e.key === "Escape") done(false); };
    m.addEventListener("click", (e) => { if (e.target === m) done(false); const b = e.target.closest("[data-v]"); if (b) done(b.dataset.v === "1"); });
    document.addEventListener("keydown", onKey);
    document.body.appendChild(m);
  });
}

/* ---------- Home page ---------- */
let current = null, busy = false;

async function refreshStats() {
  if (!$("#statTotal")) return;
  try {
    const d = await api("/analytics");
    $("#statTotal").textContent = $("#cTotal").textContent = d.total_quotes;
    $("#statFav").textContent = $("#cFav").textContent = d.total_favorites;
    $("#statAuthors").textContent = d.unique_authors;
    $("#statTop").textContent = d.top_author ? `${d.top_author.name} (${d.top_author.count})` : "—";
    $("#recent").innerHTML = d.recent_activity.length
      ? d.recent_activity.map((r) => `<li>${esc(r.quote.slice(0, 90))}${r.quote.length > 90 ? "…" : ""}<br><small>${esc(r.author)} · ${fmtDate(r.created_at)}</small></li>`).join("")
      : `<li class="empty">No activity yet. Generate your first quote.</li>`;
  } catch (e) { toast(e.message, "error"); }
}

function renderCurrent(q) {
  current = q;
  $("#quoteBox").innerHTML = `<div class="pop"><p class="qtext">“${esc(q.quote)}”</p><span class="qauthor">— ${esc(q.author)}</span><span class="tag">${esc(q.category || "General")}</span></div>`;
  $("#favBtn").textContent = q.is_favorite ? "💖 Favorited" : "🤍 Favorite";
  ["copyBtn", "shareBtn", "favBtn"].forEach((id) => ($("#" + id).disabled = false));
}

async function generate() {
  if (busy) return;
  busy = true;
  const btns = [$("#genBtn"), $("#surpriseBtn")];
  btns.forEach((b) => (b.disabled = true));
  $("#quoteBox").innerHTML = `<div class="spin" role="status" aria-label="Loading"></div>`;
  try {
    const d = await api("/quote/random");
    renderCurrent(d.quote);
    toast("Quote fetched and saved to history");
    refreshStats();
  } catch (e) {
    $("#quoteBox").innerHTML = `<div class="err"><p>😕 ${esc(e.message)}</p><button class="btn primary" id="retryBtn">Retry</button></div>`;
    $("#retryBtn").addEventListener("click", generate);
    toast(e.message, "error");
  } finally {
    busy = false;
    btns.forEach((b) => (b.disabled = false));
  }
}

async function toggleFav(q, after) {
  try {
    const d = await api(`/quotes/${q.id}/favorite`, { method: "PUT" });
    toast(d.quote.is_favorite ? "Added to favorites" : "Removed from favorites");
    after(d.quote); refreshStats();
  } catch (e) { toast(e.message, "error"); }
}

const GRADS = ["#7C3AED,#F472B6", "#172554,#7C3AED", "#0f766e,#172554", "#be185d,#172554", "#4f46e5,#06b6d4", "#9333ea,#f59e0b"];
async function showInspire() {
  const m = $("#inspire"), b = $("#inspNext");
  if (b.disabled) return;
  m.style.background = `linear-gradient(135deg,${GRADS[Math.floor(Math.random() * GRADS.length)]})`;
  m.classList.add("open");
  b.disabled = true;
  try {
    const d = await api("/quote/random");
    $("#inspText").innerHTML = `<div class="pop"><p class="qtext">“${esc(d.quote.quote)}”</p><span class="qauthor">— ${esc(d.quote.author)}</span></div>`;
    refreshStats();
  } catch (e) { $("#inspText").innerHTML = `<p>${esc(e.message)}</p>`; }
  b.disabled = false;
}

async function loadFeatured() {
  const box = $("#featBox");
  try {
    let d;
    try { d = await api("/quotes/featured"); }
    catch (e) { if (!/No quotes/.test(e.message)) throw e; await api("/quote/random"); d = await api("/quotes/featured"); refreshStats(); }
    let fq = d.quote;
    const draw = () => {
      box.innerHTML = `<p class="qtext">“${esc(fq.quote)}”</p><span class="qauthor">— ${esc(fq.author)}</span><div class="actions"><button class="btn sm" id="featFav">${fq.is_favorite ? "💖 Saved" : "🤍 Save to favorites"}</button></div>`;
      $("#featFav").addEventListener("click", () => toggleFav(fq, (u) => { fq = u; draw(); }));
    };
    draw();
  } catch (e) { box.innerHTML = `<p class="empty">${esc(e.message)}</p>`; }
}

document.addEventListener("DOMContentLoaded", () => {
  if (!$("#genBtn")) return;
  $("#genBtn").addEventListener("click", generate);
  $("#surpriseBtn").addEventListener("click", generate);
  $("#heroGen").addEventListener("click", () => { $("#generator").scrollIntoView(); generate(); });
  $("#copyBtn").addEventListener("click", () => current && copyText(fmt(current)));
  $("#shareBtn").addEventListener("click", () => current && shareQuote(current));
  $("#favBtn").addEventListener("click", () => current && toggleFav(current, renderCurrent));
  $("#inspireBtn").addEventListener("click", showInspire);
  $("#inspNext").addEventListener("click", showInspire);
  $("#inspClose").addEventListener("click", () => $("#inspire").classList.remove("open"));
  document.addEventListener("keydown", (e) => {
    const tag = document.activeElement.tagName;
    if (e.key === "Escape") document.querySelectorAll(".modal.open").forEach((m) => m.classList.remove("open"));
    else if (e.code === "Space" && !["INPUT", "BUTTON", "SELECT", "TEXTAREA", "A"].includes(tag)) { e.preventDefault(); generate(); }
    else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "c" && current && !String(window.getSelection())) { e.preventDefault(); copyText(fmt(current)); }
  });
  refreshStats();
  loadFeatured();
});
