/* Shared list view used by history.html and favorites.html (favorites.js calls it with favoritesOnly) */
function initList({ favoritesOnly = false } = {}) {
  const st = { page: 1, search: "", sort: "newest", category: "" };
  const list = $("#list"), more = $("#more"), count = $("#count"), cache = {};
  let loading = false, timer;

  const card = (q) => `<article class="card glass item" data-id="${q.id}">
    <p class="qtext">“${esc(q.quote)}”</p>
    <span class="qauthor">— ${esc(q.author)}</span><span class="tag">${esc(q.category || "General")}</span>
    <div><small>${fmtDate(q.created_at)} · ${q.is_favorite ? '<span class="fav">♥ Favorite</span>' : "Not a favorite"}</small></div>
    <div class="actions">
      <button class="btn sm" data-act="fav">${q.is_favorite ? "💖 Unfavorite" : "🤍 Favorite"}</button>
      <button class="btn sm" data-act="copy">📋 Copy</button>
      <button class="btn sm" data-act="share">🔗 Share</button>
      <button class="btn sm danger" data-act="del">🗑 Delete</button>
    </div></article>`;

  async function load(reset) {
    if (loading) return;
    loading = true;
    if (reset) { st.page = 1; list.innerHTML = `<div class="spin"></div>`; }
    const qs = new URLSearchParams({ search: st.search, sort: st.sort, category: st.category, page: st.page, per_page: 10 });
    try {
      const d = await api(`/quotes/${favoritesOnly ? "favorites" : "history"}?${qs}`);
      if (reset) list.innerHTML = "";
      d.items.forEach((q) => (cache[q.id] = q));
      list.insertAdjacentHTML("beforeend", d.items.map(card).join(""));
      count.textContent = `${d.total} quote${d.total === 1 ? "" : "s"}`;
      if (!list.children.length)
        list.innerHTML = `<div class="empty">${favoritesOnly && !st.search && !st.category ? "No favorites yet. Tap the heart on any quote to save it here." : st.search || st.category ? "No quotes match your search." : "Your history is empty. Generate a quote to get started."}</div>`;
      more.style.display = d.has_more ? "" : "none";
    } catch (e) {
      list.innerHTML = `<div class="empty">${esc(e.message)}<br><br><button class="btn primary" id="retry">Retry</button></div>`;
      $("#retry").addEventListener("click", () => load(true));
    }
    loading = false;
  }

  list.addEventListener("click", async (e) => {
    const b = e.target.closest("[data-act]"); if (!b) return;
    const q = cache[b.closest(".item").dataset.id];
    if (b.dataset.act === "copy") copyText(fmt(q));
    else if (b.dataset.act === "share") shareQuote(q);
    else if (b.dataset.act === "fav") {
      try {
        const d = await api(`/quotes/${q.id}/favorite`, { method: "PUT" });
        toast(d.quote.is_favorite ? "Added to favorites" : "Removed from favorites");
        load(true);
      } catch (err) { toast(err.message, "error"); }
    } else if (b.dataset.act === "del") {
      if (!(await confirmDialog("Delete this quote permanently?"))) return;
      try { await api(`/quotes/${q.id}`, { method: "DELETE" }); toast("Quote deleted"); load(true); }
      catch (err) { toast(err.message, "error"); }
    }
  });
  $("#search").addEventListener("input", (e) => { clearTimeout(timer); timer = setTimeout(() => { st.search = e.target.value.trim(); load(true); }, 300); });
  $("#sort").addEventListener("change", (e) => { st.sort = e.target.value; load(true); });
  $("#category").addEventListener("change", (e) => { st.category = e.target.value; load(true); });
  more.addEventListener("click", () => { st.page++; load(false); });
  const clear = $("#clearAll");
  if (clear) clear.addEventListener("click", async () => {
    if (!(await confirmDialog("Clear your entire quote history, including favorites? This cannot be undone."))) return;
    try { const d = await api("/quotes/history", { method: "DELETE" }); toast(`Cleared ${d.deleted} quotes`); load(true); }
    catch (err) { toast(err.message, "error"); }
  });
  load(true);
}
document.addEventListener("DOMContentLoaded", () => { if (document.body.dataset.page === "history") initList({ favoritesOnly: false }); });
