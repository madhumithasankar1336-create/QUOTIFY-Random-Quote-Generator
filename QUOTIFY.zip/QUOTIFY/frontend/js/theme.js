(function () {
  const saved = localStorage.getItem("quotify-theme") ||
    (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
  document.documentElement.setAttribute("data-theme", saved);
  document.addEventListener("DOMContentLoaded", () => {
    const btn = document.getElementById("themeToggle");
    if (!btn) return;
    const sync = () => (btn.textContent = document.documentElement.dataset.theme === "dark" ? "☀️" : "🌙");
    sync();
    btn.addEventListener("click", () => {
      const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
      document.documentElement.dataset.theme = next;
      localStorage.setItem("quotify-theme", next);
      sync();
    });
  });
})();
